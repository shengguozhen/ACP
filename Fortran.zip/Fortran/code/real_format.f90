program test_real_format
real(4)::x=-2.0_4
write(*,*) x
end program 

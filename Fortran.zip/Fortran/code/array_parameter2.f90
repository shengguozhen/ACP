program main
implicit none
integer(kind=2):: i,j,a(3,4),s
data((a(i,j),i=1,3),j=1,4)/1,2,3,4,5,6,7,8,9,10,11,12/
call sum1(a,s)
write(*,"('sum=',i4)")s
call sum1(a(1,2),s)
write(*,"('sum=',i4)")s
call sum1(a(1,1),s)
write(*,"('sum=',i4)")s
call sum1(a(2,1),s)
write(*,"('sum=',i4)")s
end


subroutine sum1(b,sum)
    implicit none
    integer(kind=2) :: b(-1:1),i
    integer(kind=2) :: sum
    sum=0
    do i=-1,1
         sum=sum+b(i)
    end do
    return
end


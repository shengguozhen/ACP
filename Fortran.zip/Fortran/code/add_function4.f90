program main
implicit none
real*8 :: a,b,s
real, external :: add  ! 声明add是外部函数，冒号不可省，与real必用逗号隔开
read(*,*)a,b
s=add(a,b)
write(*,*)s
stop; end
function  add(a1,b1)    ! 函数定义的第二种形式
implicit none
real*8 :: a1,b1
real add    ! 函数名add声明为实型
add=a1+b1
return; end


program main
implicit none
integer :: n,i,j,k,l

k=1
write(*,*) "输入最大的数: (小于10的10次方)  "
read(*,*) l

n=2
write(*,*) n  ! 2是素数，下面循环从3开始

do n=3,l,2
      j=sqrt(real(n))
      i=2
      do while(i<=j.and.(mod(n,i)/=0))  
          ! mod( )是求余函数，mod(n,i)就是n对i求余 
            i=i+1
      end do
      if(i>j) then
            write(*,*) n
            k=k+1
      end if
end do
write(*,'(A,I11,A,I11,A)') "从 1 到",l,"，一共有",k,"个素数。"
stop
end


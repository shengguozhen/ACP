!!!!!!
!    Module中有函数时必须在contains命令之后（即在某一行写上contains然后下
!    面开始写函数）。并且module中定义过的变量在module里的
!    函数中可直接使用，函数之间也可以直接相互调用(包括主程序或其他包含module的子函数中)，
!    连module中的自定义函数在被调用时也不用先声明。
!     编译时，必须先编译module，再编译主函数
!!!!!!
module opModule
    real(kind = 4) :: M_result
contains
    subroutine prtHi()
        implicit none
        print *, 'hello fortran, hello 2016.11.16 10:55'
    end subroutine prtHi

    real(kind=4) function M_add_func(a, b)
    implicit none
    real(kind=4) :: a, b

    M_result = a + b
    M_add_func = M_result

    end function M_add_func

end module opModule

program helloworld
use opModule  
! 在主程序或函数中使用时，需要在声明之前先写上一行：
!  use module_name.
implicit none

real(kind = 4):: a = 2.0, b = 3.0, add_result = 0.0

interface   ! 声明函数调用接口，sub无需声明可直接调用
    real(kind=4) function add_func(a, b)
    implicit none
        real(kind=4) :: a, b
    end function add_func
end interface

    ! 注意sub的调用方式 call subname(╬aram1, ...)
    call add_sub(a, b, add_result)  
    Print *, "Hello World!", add_result, add_func(a, b)

    call prtHi()

    print*, M_add_func(2.3, 4.3), M_result

end program helloworld

subroutine add_sub(a, b, add_result)
implicit none
real(kind=4) :: a, b, add_result

add_result = a + b;

end subroutine add_sub

real function add_func(a, b)
implicit none
real(kind=4) :: a, b
add_func = a + b
end function add_func



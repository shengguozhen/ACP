program main
implicit none
integer :: i, j
do i=1, 3
      j=1
      loop1: do while(j<=9)
      if(mod(j,2)==0) then
           j=j+1
           cycle  !cycle等价于cycle loop1，结束循环loop1的本次循环
      end if
      write(*,*) i, j
      j=j+1
      end do loop1
end do
stop 
end


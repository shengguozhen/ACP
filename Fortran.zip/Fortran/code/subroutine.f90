program main
implicit none
real w(5,5),x1,x2
call message  !调用子程序message，输出信息：Enter 5*5 matrix:
call readin(w) !调用子程序readin，给数组w输入值
call opp(w,x1,x2) !调用子程序opp，分别求出矩阵w的两条对角线元素之和，并由x1、x2带回。实参x1、x2必为变量。
write(*,100) x1,x2
100 format(1x,'The two sum of opposite angles elements:'  &
/1x,'x1=',f8.2,4x,',x2=',f8.2)
end

subroutine opp(a,s1,s2)  
! 子程序opp求矩阵a的两条对角线的元素之和
implicit none
integer i
real a(5,5),s1,s2
s1=0
do i=1,5
     s1=s1+a(i,i)
end do
s2=0
do i=1,5
     s2=s2+a(i,6-i)
end do
end

subroutine readin(a)
! 子程序readin给数组a输入值
implicit none
integer i,j
real a(5,5)
do i=1,5
      read(*,*)(a(i,j),j=1,5)
end do
end

subroutine message   
! 子程序message用来输出信息
     write(*,*) 'Enter 5*5 matrix:'
end subroutine message

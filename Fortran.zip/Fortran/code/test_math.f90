program main
write(*,*) 3.0*(1/2)/2.0
write(*,*) 2*3/2**2 
write(*,*) 1.5*(4/3*2)+6
end


program main
implicit none
integer :: j,k,n,t
integer(kind=2), allocatable :: g(:,:)
write(*,*) "输入矩阵的阶:  "
read(*,*) n
allocate(g(0:n-1,-1:n-2))
write(*, "(a,i2,a)") "输入一个",n, " 阶矩阵："
do j=0,n-1
     read(*,*)(g(j,k),k=-1,n-2)
end do
do k=-1,n-2
      write(*, "(10i3)") g(:,k)
end do
deallocate(g)
stop
end


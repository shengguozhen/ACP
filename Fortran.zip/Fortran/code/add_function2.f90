program main
implicit none
real :: a,b,add,s  ! 声明add为实型，是函数，还是变量，由add的使用情形来定
read(*,*) a,b
s=add(a,b)   ! add的使用情形说明它是函数，不是变量。
write(*,*)s
stop
end
real function add(a1,b1)   ! 函数定义的第一种形式
implicit none
real :: a1,b1
add=a1+b1
return
end

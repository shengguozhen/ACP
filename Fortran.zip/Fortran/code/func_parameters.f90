program main
implicit none
integer(kind=2) :: n,m
real a,b
integer(kind=2), external :: test1
n=1
m=test1(n)  !调用函数test1(n)时，形参n就是实参变量n，形参与实参同名
write(*, "('m=',i4,4x, 'n=',i4)")m,n
b=10.0
call test2(a,b) !调用函数test2(a,b)时，形参x、y就是实参变量a、b 
write(*, "('a=',f6.1,4x, 'b=',f6.1)")a,b
stop
end
integer(kind=2) function test1(n)
    implicit none
    integer(kind=2)::n
    n=n+1
    test1=n*100
    return
end

subroutine test2(x,y)
    implicit none
    real x,y
    y=y+10.0
    x=y*10.0
    return
end


program main
implicit none
write(*,100) 246,1234 
write(*,200) 246,1234
write(*,300) 246,1234
write(*,400) 246,1234
write(*,500) 246,1234
write(*,600) 246,1234

100     format(1x,i3,i4)
200     format(' i=',i3,'j=',i4)
300     format('i=',i3, ' j=',i4)
400     format(i3,i4)
500     format(4x,i3,i4)
600     format('0',i3,i4)

write(*,700) 7.42,-194.31,0.12
700     format(1x,f6.3,f10.2,f4.1)

write (*,'(F9.2)') -78567.83
write (*,'(F11.4)') 0.000678576
write(*,800) 7.42,-194.31,0.12
800     format(1x,e11.3,e11.2e3,e8.1)

write(*,900) 1.378675893D+02,1784.5D-03
900    format(1x,d18.10,f11.7)

write(*,1000) 5,4.2,6,7.8
1000   format(1x, i3, f6.2/1x,i3,f6.2/)	

write(*,'(A,I6,2x,A,$)') "test ",100, "fine"
write(*,'(2x,A,I6,2x,A)') "test ",200, "fine"
end

program main
read(*,*) a,b
s=add(a,b)  !调用函数add
write(*,*) s
stop
end
function add(a1,b1)
add=a1+b1
return
end

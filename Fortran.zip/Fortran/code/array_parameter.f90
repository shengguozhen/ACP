program main
implicit none
integer i,j,a(3,4),s
integer, external :: sum
data ((a(i,j),i=1,3),j=1,4)/1,2,3,4,5,6,7,8,9,10,11,12/
s=sum(a)   !传递结合的起始位置，即b(1)的存储单元的第
                   !一个字节取为a(1,1)存储单元的第一个字节。结合结果：
                   ! b(1)~a(1,1)、b(2)~a(2,1)、b(3)~a(3,1)
write(*,"('sum=',i4)")s
s=sum(a(1,2))    !传递结合的起始位置，即 b(1) 的存储单元的第一个
                             !字节取为 a(1,2) 存储单元的第一个字节。结合
                             !结果：b(1)~a(1,2)、b(2)~a(2,2)、b(3)~a(3,2)
write(*,"('sum=',i4)") s
s=sum(a(1,1))    ! 传递结合的起始位置，与s=sum(a)等价。
                             !结合结果：b(1)~a(1,1)、b(2)~a(2,1)、b(3)~a(3,1)
write(*,"('sum=',i4)")s
s=sum(a(2,1))    ! 传递结合的起始位置，即b(1)的存储单元
                             !的第一个字节取为a(2,1)存储单元的第一个字节。
                             !结合结果：b(1)~a(2,1)、b(2)~a(3,1)、b(3)~a(1,2)
write(*,"('sum=',i4)")s
stop
end
integer function sum(b)
    implicit none
    integer::b(3),i
    sum=0
    do i=1,3
         sum=sum+b(i)
    end do
    return
end


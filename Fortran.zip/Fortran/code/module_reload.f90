module abs_module
  implicit none
  interface abs_generic
  module procedure abs_f, dabs_f, iabs_f
  end interface
contains
function abs_f(x)
real(4) abs_f, x
if( x<0.0_4 ) then
  abs_f = -x
else
  abs_f = x
end if
end function abs_f
  
function dabs_f(x)
real(8) dabs_f, x
if( x<0.0_8 ) then
  dabs_f = -x
else
  dabs_f = x
end if
end function dabs_f
  
function iabs_f(x)
integer(4) iabs_f, x
if( x<0 ) then
  iabs_f = -x
else
  iabs_f = x
end if
end function iabs_f
end module abs_module
  
program Fcode_cn
use abs_module
real(4):: x=-2.0_4 ! F90 styel, a 4-byte real number
real(8):: y=-3.0_8
integer(4)::z=-4
  
print*, abs_f(x),  abs_generic(x)
print*, dabs_f(y), abs_generic(y)
print*, iabs_f(z), abs_generic(z)
  
end


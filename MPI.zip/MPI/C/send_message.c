#include "mpi.h"
#include <string.h>
#include <stdio.h>
int  main( argc, argv )
int argc;
char **argv;
{
char message[40];
int myrank;
MPI_Status status;
MPI_Init( &argc, &argv );
/* MPI程序的初始化*/
MPI_Comm_rank( MPI_COMM_WORLD, &myrank );
/* 得到当前进程的标识*/
if (myrank == 0) /* 若是 0 进程*/
{
/* 先将字符串拷贝到发送缓冲区message中,然后调用MPI_Send语句将它发出.用
strlen(message)指定消息的长度,用MPI_CHAR指定消息的数据类型,1指明发往进程1, 
使用的消息标识是99, MPI_COMM_WORLD是包含本进程0 和接收消息的进程1 的通信域.
发送方和接收方必须在同一个通信域中,由通信域来统一协调和控制消息
的发送和接收*/
strcpy(message,"Hello, process 1!");
MPI_Send(message, strlen(message), MPI_CHAR, 1,
99,MPI_COMM_WORLD);
printf("A message sent from processor %i.\n", myrank);
}
else if(myrank==1) /* 若是进程 1 */
{
/*进程1直接执行接收消息的操作.这里它使用message作为接收缓冲区.由此可见对于同
一个变量在发送进程和接收进程中的作用是不同的.它指定接收消息的最大长度为40. 消
息的数据类型为MPI_CHAR字符型.接收的消息来自进程0. 而接收消息携带的标识必须为
99. 使用的通信域也是MPI_COMM_WORLD. 接收完成后的各种状态信息存放在status中.
接收完成后它直接将接收到的字符串打印在屏幕上*/
MPI_Recv(message, 40, MPI_CHAR, 0, 99, MPI_COMM_WORLD, &status);
printf("Message \"%s\" received from processor %i.\n", message, myrank);
}
MPI_Finalize();
/* MPI程序结束*/
}

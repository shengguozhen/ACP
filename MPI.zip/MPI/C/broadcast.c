/************************************    
// 程序功能: MPI_Bcast函数用法          
// 作 成 者：Erick.Wang     
// 作成日期：2016/12/14     
// 详细说明：
//************************************/  

#include <stdio.h>
#include <mpi.h>

#pragma comment(lib,"mpi.lib")

/************************************************
MPI_BCAST(buffer,count,datatype,root,comm) 
    IN/OUT　buffer　　  通信消息缓冲区的起始地址(可变)
    IN　　　 count　  　 通信消息缓冲区中的数据个数(整型) 
    IN 　　　datatype 　通信消息缓冲区中的数据类型(句柄) 
    IN　　　 root　  　　发送广播的根的序列号(整型) 
    IN 　　　comm   　　通信子(句柄) 
int MPI_Bcast(void* buffer,int count,MPI_Datatype datatype,int root, MPI_Comm comm) 

MPI_BCAST是从一个序列号为root的进程将一条消息广播发送到组内的所有进程,
包括它本身在内.调用时组内所有成员都使用同一个comm和root,
其结果是将根的通信消息缓冲区中的消息拷贝到其他所有进程中去.
**********************************************/

int main(int argc,char *argv[]){
    int rank,nproc;

    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&nproc);
    
    int data = 10;
    int tag = 100;
	int master = 0;
    MPI_Status status;

	printf("data = %d in %d process.\n",data,rank);

    if(rank==master){
		scanf("%d", &data);
		printf("now data = %d in %d process. \n", data, rank);
		MPI_Bcast(&data,1,MPI_INT,master,MPI_COMM_WORLD);
	}
	else{
	MPI_Bcast(&data,1,MPI_INT,master,MPI_COMM_WORLD);
	printf("now data = %d in %d process.\n",data,rank);
	}
    
    MPI_Finalize();
    return 0;
}

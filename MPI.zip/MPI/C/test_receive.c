#include "mpi.h"
#include <stdio.h>
int main(argc, argv)
int argc;
char **argv;
{
int rank, size, i, j, buf[1];
MPI_Status status;
MPI_Init( &argc, &argv );
MPI_Comm_rank( MPI_COMM_WORLD, &rank );
MPI_Comm_size( MPI_COMM_WORLD, &size );
if (rank == 0) {
	for (i=0; i<10*(size-1); i++) {
		MPI_Recv( buf, 1, MPI_INT, MPI_ANY_SOURCE,
			5, MPI_COMM_WORLD, &status );
		printf( "i=%d, Msg=%d from process %d with tag %d\n",
			i, buf[0], status.MPI_SOURCE, status.MPI_TAG );
		}
	}
else {
	for (j=0; j<10; j++){
		buf[0]=rank+j;
		MPI_Send( buf, 1, MPI_INT, 0, j, MPI_COMM_WORLD );
		}
	}
MPI_Finalize();
}

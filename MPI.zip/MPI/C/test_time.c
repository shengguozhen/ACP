#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"
int main( int argc, char **argv )
{
int err = 0;
double t1, t2;
double tick;
int i;
MPI_Init( &argc, &argv );
t1 = MPI_Wtime();/*得到当前时间t1*/
t2 = MPI_Wtime();/*得到当前时间t2*/
if (t2 - t1 > 0.1 || t2 - t1 < 0.0) {
/* 若连续的两次时间调用得到的时间间隔过大这里是超过0.1秒或者后调用的函数
得到的时间比先调用的时间小则时间调用有错*/
err++;
fprintf( stderr,
"Two successive calls to MPI_Wtime gave strange results: (%f) (%f)\n",
t1, t2 );
}
/* 循环测试10次每次循环调用两次时间函数两次时间调用的时间间隔是1秒 */
for (i = 0; i<10; i++) {
t1 = MPI_Wtime();/*计时开始*/
sleep(1);/*睡眠1秒钟*/
t2 = MPI_Wtime();/*计时结束*/
if (t2 - t1 >= (1.0 - 0.01) && t2 - t1 <= 5.0) break;
/* 两次计时得到的时间间隔合理 则退出*/
if (t2 - t1 > 5.0) i = 9;
/* 若两次计时得到的时间间隔过大则改变循环计数变量的值迫使程序从循环
退出*/
}
/* 从上知若计时函数正确则不需循环10次程序即从循环退出否则会重复执行到10
次*/
if (i == 10) {
/* 计时函数不正确 */
fprintf( stderr, "Timer around sleep(1) did not give 1 second; gave %f\n",t2 - t1 );
err++;
}
tick = MPI_Wtick();
/* 得到一个时钟滴答的时间*/
if (tick > 1.0 || tick < 0.0) {
/* 该时间太长或者为负数则该时间不正确*/
err++;
fprintf( stderr, "MPI_Wtick gave a strange result: (%f)\n", tick );
}
MPI_Finalize( );
}

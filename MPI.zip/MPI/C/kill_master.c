#include "mpi.h"
#include <stdio.h>
#include <string.h>
/* 本例子分两种情况一种是masternode == 0 是缺省的情况另一种是 masternode != 0
是指定最后一个进程为主进程的情况
*/
int main( int argc, char **argv )
{
int node, size, i;
int masternode = 0;
/* 设置缺省初始值*/
MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &node);
MPI_Comm_size(MPI_COMM_WORLD, &size);
/*检查参数 */
for (i=1; i<argc; i++) {
	fprintf(stderr,"myid=%d,procs=%d,argv[%d]=%s\n",node,size,i,argv[i]);
	if (argv[i] && strcmp( "lastmaster", argv[i] ) == 0) {
		masternode = size-1;
/* 将最后一个进程设置为master*/
	}
}
if(node == masternode) {
/* 由master进程执行退出操作*/
	fprintf(stderr,"myid=%d is masternode Abort!\n",node);
				MPI_Abort(MPI_COMM_WORLD, 99);
}
else {
/* 非master进程等待*/
	fprintf(stderr,"myid=%d is not masternode Barrier!\n",node);
				MPI_Barrier(MPI_COMM_WORLD);
}

MPI_Finalize();
}

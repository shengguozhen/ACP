program main
include 'mpif.h'
character*(MPI_MAX_PROCESSOR_NAME) name
integer resultlen, version, subversion, ierr
call MPI_Init( ierr )
name = " "
! 首先将名字赋为空
call MPI_Get_processor_name( name, resultlen, ierr )
! 得到机器的名字name和该名字的字符长度resultlen
call MPI_GET_VERSION(version, subversion,ierr)
! 得到MPI的版本号
errs = 0
do i=resultlen+1, MPI_MAX_PROCESSOR_NAME
if (name(i:i) .ne. " ") then
! 若返回的名字name的resultlen后还有非空字符则认为该名字有错误
errs = errs + 1
endif
enddo
if (errs .gt. 0) then
print *, 'Non-blanks after name'
else
print *, name, " MPI version",version, ".", subversion
endif
call MPI_Finalize( ierr )
end

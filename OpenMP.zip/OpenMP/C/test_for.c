#include <omp.h>
#include <stdio.h>
#define NUM_THREADS 4
int main () 
{	int i, id, num_steps;
    num_steps = 20; 
	omp_set_num_threads(NUM_THREADS); 
      #pragma omp parallel private(id,i)
      {   id = omp_get_thread_num(); 
           #pragma omp for 
	      for (i=0; i<num_steps; i++)
              { 
	            printf("id=%d, i=%d \n",id,i); 
	          } 
      }
}


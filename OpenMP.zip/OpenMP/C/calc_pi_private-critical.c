#include <omp.h>
#include <stdio.h>
static long num_steps = 10000000;  double step; 
//gcc gives wired result when num_steps is large, icc is good.
#define NUM_THREADS 4 
int main () 
{	int i, id;   double  x, sum, pi=0.0,start_time, end_time; 
	step = 1.0/(double) num_steps; 
	omp_set_num_threads(NUM_THREADS);
       start_time=omp_get_wtime();
       #pragma omp parallel private (x, sum, i, id) 
       {   x=0.0;
           id = omp_get_thread_num(); 
	       for (i=id, sum=0.0; i< num_steps; i=i+NUM_THREADS){ 
	          x = (i+0.5)*step; sum += 4.0/(1.0+x*x); 
            } 
             #pragma omp critical
	        pi += sum*step;
        }
         end_time=omp_get_wtime();
         printf("Pi=%.14f\n Running time:%f \n", pi, end_time-start_time);
}


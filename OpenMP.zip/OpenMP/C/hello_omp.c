#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
  
int main(int argc, char *argv[]){  
    int nthreads, tid;  
    int nprocs;  
    char buf[32];  
    //fork a team of threads  
#pragma omp parallel private(nthreads,tid) num_threads(8)  
    {  
        //obtain and print thread id  
        tid = omp_get_thread_num();  
        printf("Hello World from OMP thread %d\n", tid);  
        //only master thread does this  
        if (tid == 0){  
            nthreads = omp_get_num_threads();  
            printf("Number of threads %d\n", nthreads);  
        }  
    }  
    return 0;  
}  

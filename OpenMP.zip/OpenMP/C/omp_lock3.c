#include <stdio.h>
#include <omp.h>
void skip(int i) {printf("in skip, my id=%d \n",i);}
void work(int i) {printf("in work, my id=%d \n",i);}
int main()
{
 omp_lock_t lck;
 int id;
 omp_init_lock(&lck);
 #pragma omp parallel shared(lck) private(id)
	{
	id = omp_get_thread_num();
    printf("Before lock, My thread id is %d.\n", id);

	omp_set_lock(&lck);
	/* only one thread at a time can execute this printf */
	printf("My thread id is %d.\n", id);
    printf("in lock, id=%d \n",id);
	omp_unset_lock(&lck);

	}
 omp_destroy_lock(&lck);
 return 0;
}

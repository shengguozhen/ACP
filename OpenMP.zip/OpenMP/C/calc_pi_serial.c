/* Serial Code */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
static long num_steps = 20000000; 
double step; 
int main () 
{	  int i;  double x, pi, sum = 0.0, start_time, end_time;    
	  step = 1.0/(double) num_steps; 
      start_time=clock();
	  for (i=0;i< num_steps; i++){ 
	     x = (i+0.5)*step; 
	     sum = sum + 4.0/(1.0+x*x); 
	  } 
	  pi = step * sum; 
      end_time=clock();
      printf("Pi=%.14f\n Running time:%f \n", pi, end_time-start_time);
}


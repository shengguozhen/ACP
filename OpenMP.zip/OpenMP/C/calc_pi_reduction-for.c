#include <omp.h>
#include <stdio.h>
#define NUM_THREADS 4
static long num_steps = 1000000000;         double step; 
int main () 
{	int i, id; double x, pi, sum=0.0, start_time, end_time; 
	step = 1.0/(double) num_steps; 
	omp_set_num_threads(NUM_THREADS) ;
       start_time=omp_get_wtime();
       #pragma omp parallel private(x, id ,i)
      {   id = omp_get_thread_num();
           #pragma omp for  private(x) reduction(+:sum)
	      for (i=0; i< num_steps; i++){
                 x = (i+0.5)*step;
                 sum += 4.0/(1.0+x*x);
	      }
      }
      pi=sum*step; end_time=omp_get_wtime();
      printf("Pi=%.14f\n Running time= %f \n",pi,end_time-start_time);
}


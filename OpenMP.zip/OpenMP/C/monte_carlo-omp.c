#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#define NUM_THREADS 4
#include <omp.h>
int main()
{
    long long max=1000000000;
    long long i,count=0;
    double x,y,z,bulk,start_time,end_time;
    time_t t;
	omp_set_num_threads(NUM_THREADS);
    start_time=omp_get_wtime();
    //产生以当前时间开始的随机种子
    srand((unsigned) time(&t));
	#pragma omp parallel for private(x,y,z) reduction(+:count)
	for(i=0;i<max;i++)
		{   x=rand();        x=x/RAND_MAX;
			y=rand();        y=y/RAND_MAX;
			z=rand();        z=z/RAND_MAX;
			if((x*x+y*y+z*z)<=1)
				count++;
		}
	bulk=8.0*(double)count/(double)max;
	end_time=omp_get_wtime();
	printf("Sphere bulk is %f \n", bulk);
	printf("Calculated Pi = %f \n", bulk/4.0*3.0);
    printf("Real       Pi = %.14f\n", 4.0*atan(1.0));
	printf("Running time is %f \n", end_time-start_time);

	return 0;
}


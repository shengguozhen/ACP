#include <iostream>
#include <unistd.h>
#include <omp.h>

static omp_lock_t lock;
void putMes(int i)
{
	printf("AA:i=%d \n", i);
    omp_set_lock(&lock); //获得互斥器
	printf("BB:i=%d \n", i);
    omp_unset_lock(&lock); //释放互斥器

	while (! omp_test_lock(&lock)) {
			printf("CC:i=%d \n", i);
		}
	printf("DD:i=%d \n", i);
	omp_unset_lock(&lock);
}

int main()
{
    omp_init_lock(&lock); // 初始化互斥锁
	#pragma omp parallel for
		for (int i = 0; i < 4; i++) 
		{
			putMes(omp_get_thread_num()); //把线程号传过去
		}
    omp_destroy_lock(&lock); //销毁互斥器
    return 0;
}

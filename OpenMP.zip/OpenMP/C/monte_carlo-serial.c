#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
    long long max=1000000000;
    long long i,count=0;
    double x,y,z,bulk,start_time,end_time;
    time_t t;
    start_time=clock();
    //产生以当前时间开始的随机种子
    srand((unsigned) time(&t));
	for(i=0;i<max;i++)
		{   x=rand();  x=x/RAND_MAX;
			y=rand();  y=y/RAND_MAX;
			z=rand();  z=z/RAND_MAX;
			if((x*x+y*y+z*z)<=1)
				count++;
		}
	//printf("count= %d \n", count);
	//printf("x=%f, y=%f, z=%f \n", x,y,z);

    bulk=8.0*(double)count/(double)max;

    //printf("count and double count are  %d, %f \n", count, (double)count);
	end_time= clock();
	printf("Sphere bulk is %f \n", bulk);
	printf("Pi is %f \n",bulk*3.0/4.0);
	printf("Running time is %f \n", (end_time-start_time)/1000000.0);

return 0;
}


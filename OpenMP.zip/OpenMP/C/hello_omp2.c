/* 用OpenMP/C编写Hello World代码段 */
#include <stdio.h>  
#include <stdlib.h>  
#include <omp.h>  

int main(int argc, char *argv[])
{   
 int nthreads,tid;
 char buf[32];    
       /*  Fork a team of threads      */
 #pragma omp parallel private(nthreads,tid)
 { 
    /* Obtain and print thread id  */ 
   tid = omp_get_thread_num();
   printf("Hello, world from OpenMP thread %d\n", tid);
   /*Only master thread does this  */
   if (tid == 0)
      {
         nthreads = omp_get_num_threads();
         printf(" This is thread %d, Number of threads %d\n",tid, nthreads);
      }
 }
 return 0;
}


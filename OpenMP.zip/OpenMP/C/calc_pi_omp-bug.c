 #include <omp.h>
 #include <stdlib.h>
 #include <math.h>
 #include <stdio.h>
 static long num_steps = 20000;   double step; 
//如果不加private（i)，num_steps 只要大于2000，计算结果就不对，而且每次都不同。
 #define NUM_THREADS     4 
 int main () 
 {	int i ;  double pi, sum[NUM_THREADS] , start_time, end_time ; 
    step = 1.0/(double) num_steps; 
	//printf("step=%f\n", step);
    omp_set_num_threads(NUM_THREADS); 
    start_time=omp_get_wtime();
    #pragma omp parallel private(i)
    {  int id; double x=0;
        id = omp_get_thread_num(); 
        printf("id=%d\n", id);
        for (i=id, sum[id]=0.0;i< num_steps; i=i+NUM_THREADS){ 
			  x = (i+0.5)*step;   
			  sum[id] += 4.0/(1.0+x*x); 
		      //printf("i=%d\n", i);
	    } 
    } 
    for(i=0, pi=0.0;i<NUM_THREADS;i++){ 
		pi += sum[i] * step;
       // printf("i=%d, sum[i]*step=%f \n",i, sum[i]*step);
    }
    end_time=omp_get_wtime();
    printf("Pi=%.14f\n Running time:%f \n", pi, end_time-start_time);
 }

